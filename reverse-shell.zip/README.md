# 🔁 Reverse Shell Collection (PHP & Python)

This repository contains two simple and effective reverse shell scripts:

- 🐘 `php-reverse-shell.php` — A reverse shell written in PHP (Linux compatible).
- 🐍 `python-reverse-shell.py` — A reverse shell written in Python (Linux and Windows compatible).

---

## 📦 How to Use

### 1. Start a Listener (Attacker Side)

On your machine, run:

```bash
nc -lvnp 4444
```

> ⚠️ Make sure the port (e.g., `4444`) matches the one used in the scripts.

---

### 2. PHP Reverse Shell (Linux)

1. Upload `php-reverse-shell.php` to the target machine (via file upload, RFI, or any other method).
2. Visit the script in the browser:

```
http://TARGET_IP/php-reverse-shell.php
```

3. If everything is correct, a shell session will open in your Netcat listener.

---

### 3. Python Reverse Shell (Linux/Windows)

1. Run the script on the target system:

```bash
python3 python-reverse-shell.py
```

2. A reverse shell will connect back to your listener.

---

## ⚠️ Legal Disclaimer

These scripts are for **educational and authorized penetration testing** purposes only.  
**Unauthorized use is illegal** and against ethical hacking principles.

Always get proper written permission before conducting tests on any system.

---

## 👤 Author

**Sherxon Axatov**  
📡 Telegram: [Akhatov | Blog](https://t.me/akhatov_blog)
